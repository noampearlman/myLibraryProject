
import json
from flask import Flask, render_template
from database.mydatabase import engine,Book,Customer,Loan
api = Flask(__name__)

@api.route('/')
def home():
    # fill library if empty
    
    
    return render_template("index.html",)

@api.route('/books')
def books():
    res= Book.get_ordered_data(engine)
    return render_template("books.html",books=res)
    
@api.route('/customers')
def customers():
    res= Customer.get_ordered_data(engine)
    return render_template("customers.html",customers=res)

@api.route('/loans')
def loans():
    res= Book.get_ordered_data(engine)
    return render_template("loans.html",loans=res)




# Program entry point
def main():
    # temporary database filler
    Book.create_books(engine)
    Customer.create_customers(engine)
    api.run(debug=True)

# run the program
if __name__ == "__main__": main()
