from sqlalchemy.orm import declarative_base, sessionmaker
from sqlalchemy import create_engine
from sqlalchemy import Column, Integer, String, Date, ForeignKey, MetaData

from datetime import date
import os

BASE_DIR = os.path.dirname(os.path.realpath(__file__))
connection_string='sqlite:///'+os.path.join(BASE_DIR,'myLibrary.db')
Base = declarative_base()
engine=create_engine(connection_string,echo=True)
Session = sessionmaker()

class Book(Base):
    __tablename__ = 'books'
    id = Column(Integer(),primary_key=True)
    book_name = Column(String(),nullable=False,unique=True)
    author_name = Column(String(),nullable=False)
    year_pub = Column(Integer(),nullable=False)
    book_type = Column(Integer(),nullable=False)

    def __repr__(self):
        return f'<book>\n id: {self.id}\n name: {self.book_name}\n author: {self.author_name}\n year published: {self.year_pub}\n type: {self.book_type} '

    def get_ordered_data(self):
        local_session=Session(bind=engine)
        res = []        
        result = local_session.query(Book).order_by(Book.book_name).all()
        for row in result:
            res.append(row)
        return res

    def create_books(self):
        try:
            books=[
        {
            "book_name":"ice ball",
            "author_name":"ben",
            "year_pub":2001,
            "book_type":2
        },
        {
            "book_name":"cats",
            "author_name":"tom",
            "year_pub":1999,
            "book_type":1
        },{
            "book_name":"mouse",
            "author_name":"jerry",
            "year_pub":2002,
            "book_type":3
        },
        
        ]
            local_session=Session(bind=engine)
            for i in books:
                new_book=Book(book_name=i["book_name"],author_name=i["author_name"],year_pub=i["year_pub"],book_type=i["book_type"])
                        
                local_session.add(new_book)

                local_session.commit()

                print(f"Added {i['book_name']}")
        except:print("cant")

class Customer(Base):
    __tablename__ = 'customers'
    id = Column(Integer(),primary_key=True)
    cust_name = Column(String(),nullable=False,unique=True)
    city = Column(String(),nullable=False)
    age = Column(Integer(),default=0,nullable=False)

    def get_ordered_data(self):
        local_session=Session(bind=engine)
        res = []        
        result = local_session.query(Customer).order_by(Customer.cust_name).all()
        for row in result:
            res.append(row)
        return res
    
    def create_customers(self):
        try:
            customers=[
            {
            "cust_name":"yaniv",
            "city":"haifa",
            "age":21,
            },
            {
            "cust_name":"oren",
            "city":"hadera",
            "age":18,
            },
            {
            "cust_name":"nikita",
            "city":"netanya",
            "age":23,
            },
        ]

            local_session=Session(bind=engine)
            for i in customers:
                new_cust=Customer(cust_name=i["cust_name"],city=i["city"],age=i["age"])
                        
                local_session.add(new_cust)

                local_session.commit()

                print(f"Added {i['cust_name']}")
        except:pass

class Loan(Base):
    __tablename__ = 'loans'
    id = Column(Integer(),primary_key=True,unique=True)
    book_id = Column(Integer(),ForeignKey('books.id'))
    cust_id = Column(Integer(),ForeignKey('customers.id'))
    loan_date = Column(Date(), nullable=False)
    loan_ret_date = Column(Date(), nullable=False)


try:
    # create database
    Base.metadata.create_all(engine)
except:
    pass






























# # Global Variables
# SQLITE                  = 'sqlite'
# # MYSQL                   = 'mysql'
# # POSTGRESQL              = 'postgresql'
# # MICROSOFT_SQL_SERVER    = 'mssqlserver'

# # Table Names
# BOOKS           = 'books'
# CUSTOMERS       = 'customers'
# LOANS    ="loans"


# class MyDatabase:
#     # http://docs.sqlalchemy.org/en/latest/core/engines.html
#     DB_ENGINE = {
#         SQLITE: 'sqlite:///{DB}',
#         # MYSQL: 'mysql://scott:tiger@localhost/{DB}',
#         # POSTGRESQL: 'postgresql://scott:tiger@localhost/{DB}',
#         # MICROSOFT_SQL_SERVER: 'mssql+pymssql://scott:tiger@hostname:port/{DB}'
#     }

#     # Main DB Connection Ref Obj
#     db_engine = None

#     def __init__(self, dbtype, username='', password='', dbname=''):
#         dbtype = dbtype.lower()

#         if dbtype in self.DB_ENGINE.keys():
#             engine_url = self.DB_ENGINE[dbtype].format(DB=dbname)

#             self.db_engine = create_engine(engine_url)
#             print(self.db_engine)

#         else:
#             print("DBType is not found in DB_ENGINE")

#     def create_db_tables(self):
#         metadata = MetaData()
#         books = Table(BOOKS, metadata,
#                       Column('id', Integer, primary_key=True),
#                       Column('name', String),
#                       Column('author', String),
#                       Column('year_published', String),
#                       Column('type', Integer)
#                       )

#         customers = Table(CUSTOMERS, metadata,
#                       Column('id', Integer, primary_key=True),
#                       Column('name', String),
#                       Column('city', String),
#                       Column('age', Integer)
#                       )

#         loans = Table(LOANS, metadata,
#                         Column('id', Integer, primary_key=True),
#                         Column('cust_id', None, ForeignKey('customers.id')),
#                         Column('book_id', None, ForeignKey('books.id')),
#                         Column('loan_date', date),
#                         Column('return_date', date)
#                         )

#         try:
#             metadata.create_all(self.db_engine)
#             print("Tables created")
#         except Exception as e:
#             print("Error occurred during Table creation!")
#             print(e)

#     # Insert, Update, Delete
#     def execute_query(self, query=''):
#         if query == '' : return

#         print (query)
#         with self.db_engine.connect() as connection:
#             try:
#                 connection.execute(query)
#             except Exception as e:
#                 print(e)


#     def print_all_data(self, table='', query=''):
#         query = query if query != '' else f"SELECT * FROM '{table}';"
#         print(query)
#         res = []
#         with self.db_engine.connect() as connection:
#             try:
#                 result = connection.execute(query)
#             except Exception as e:
#                 print(e)
#             else:
#                 for row in result:
#                     res.append( row)
#                     # print(row) # print(row[0], row[1], row[2])
#                 result.close()
#         # print("\n")
#         return res

#     # Examples

#     def sample_query(self):
#         # Sample Query
#         query = "SELECT first_name, last_name FROM {TBL_USR} WHERE " \
#                 "last_name LIKE 'M%';".format(TBL_USR=USERS)
#         self.print_all_data(query=query)

#         # Sample Query Joining
#         query = "SELECT u.last_name as last_name, " \
#                 "a.email as email, a.address as address " \
#                 "FROM {TBL_USR} AS u " \
#                 "LEFT JOIN {TBL_ADDR} as a " \
#                 "WHERE u.id=a.user_id AND u.last_name LIKE 'M%';" \
#             .format(TBL_USR=USERS, TBL_ADDR=ADDRESSES)
#         self.print_all_data(query=query)

#     def delete_by_id(self,table,id):
#         # Delete Data by Id
        
#         query = f"DELETE FROM {table} WHERE id={id}"
#         self.execute_query(query)
#         self.print_all_data(USERS)


#     def sample_delete(self):
#         # Delete Data by Id
#         query = f"DELETE FROM {USERS} WHERE id=3"
#         self.execute_query(query)
#         self.print_all_data(USERS)

#         # Delete All Data
#         '''
#         query = "DELETE FROM {}".format(USERS)
#         self.execute_query(query)
#         self.print_all_data(USERS)
#         '''

#         #  Column('id', Integer, primary_key=True),
#         #               Column('color', String),
#         #               Column('model', Integer)

#     def insert_cars(self,color, model):
#         # Insert Data
#         query = f"INSERT INTO {CARS}( color, model) " \
#                 f"VALUES ( '{color}',{model});"
#         # print(query)
#         self.execute_query(query)
#         self.print_all_data(CARS)




#     def sample_insert(self):
#         # Insert Data
#         query = "INSERT INTO {}(id, first_name, last_name) " \
#                 "VALUES (3, 'Terrence','Jordan');".format(USERS)
#         self.execute_query(query)
#         self.print_all_data(USERS)

#     def sample_update(self):
#         # Update Data
#         query = "UPDATE {} set first_name='XXXX' WHERE id={id}"\
#             .format(USERS, id=3)
#         self.execute_query(query)
#         self.print_all_data(USERS)